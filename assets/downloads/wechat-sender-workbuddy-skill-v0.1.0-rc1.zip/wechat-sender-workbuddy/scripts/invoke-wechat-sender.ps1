param(
    [string]$ConfigPath = ".\config.json",
    [string]$PayloadJson,
    [switch]$LicenseStatus,
    [switch]$FocusOnly,
    [switch]$ListWindows,
    [string]$TitleFilter = ""
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $ConfigPath)) {
    throw "Config file not found: $ConfigPath. Copy config.example.json to config.json and set exe_path."
}

$config = Get-Content -Path $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
$exePath = [string]$config.exe_path
if (-not $exePath) {
    throw "config.exe_path is required."
}

$expandedExePath = [Environment]::ExpandEnvironmentVariables($exePath)
if (-not (Test-Path $expandedExePath)) {
    throw "wechat-sender.exe not found: $expandedExePath"
}

$argsList = @()
if ($LicenseStatus) {
    $argsList += "--license-status"
}
elseif ($FocusOnly) {
    $argsList += "--focus-only"
}
elseif ($ListWindows) {
    $argsList += "--list-windows"
    if ($TitleFilter) {
        $argsList += "--title-filter"
        $argsList += $TitleFilter
    }
}
elseif ($PayloadJson) {
    if (-not (Test-Path $PayloadJson)) {
        throw "Payload JSON not found: $PayloadJson"
    }
    $argsList += "--payload-json"
    $argsList += (Resolve-Path $PayloadJson).Path
}
else {
    throw "Specify one action: -LicenseStatus, -FocusOnly, -ListWindows, or -PayloadJson <path>."
}

& $expandedExePath @argsList
exit $LASTEXITCODE
