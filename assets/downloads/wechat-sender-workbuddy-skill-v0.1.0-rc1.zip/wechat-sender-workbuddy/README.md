# WeChat Sender Workbuddy Skill Package

本目录是 Agent 交付包草案，用于 Workbuddy / Codex 等 Agent 调用已安装的 `wechat-sender.exe`。

## 包内容

```text
wechat-sender-workbuddy/
├─ SKILL.md
├─ README.md
├─ config.example.json
├─ examples/
│  └─ payload.preview.json
└─ scripts/
   └─ invoke-wechat-sender.ps1
```

## 不包含

- Python 源码
- Supabase 目录
- `.env`
- license key
- Supabase token
- admin token
- service role key
- 数据库连接串

## 安装步骤

1. 安装销售版 release 包，并确认 `wechat-sender.exe` 可运行。
2. 双击 exe 或运行 `--activate-code <license-key>` 完成授权。
3. 复制 `config.example.json` 为 `config.json`。
4. 默认 `exe_path` 为 `%LOCALAPPDATA%\WechatSender\wechat-sender.exe`；如安装在其他位置，再修改 `config.json`。
5. Agent 调用 `scripts/invoke-wechat-sender.ps1`。

## 验证命令

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -LicenseStatus
Copy-Item .\examples\payload.preview.json D:\tmp\wechat-payload.preview.json
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -PayloadJson D:\tmp\wechat-payload.preview.json
```

第二条命令默认 `send=false`，只预览，不操作微信发送。


