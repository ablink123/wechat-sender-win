# Agent Skill Import Checklist

## 目标

在把 `wechat-sender-workbuddy` 导入 Workbuddy / Codex / 其他 Agent 前，确认 skill 包只负责调用已安装的 `wechat-sender.exe`，不携带源码和密钥。

## 导入前检查

- 已安装销售版 `wechat-sender.exe`。
- 已通过 GUI 或命令行完成授权激活。
- 包内已有 `config.json`，默认指向 `%LOCALAPPDATA%\WechatSender\wechat-sender.exe`。
- 仅当客户端安装在其他位置时，才需修改 `config.json` 中的 `exe_path`。
- Windows 桌面微信已登录。
- 已先运行 `--license-status`。
- 已先用 `send=false` 的 payload 做预览。

## 包内容检查

允许包含：

- `SKILL.md`
- `README.md`
- `IMPORT_CHECKLIST.md`
- `config.json`
- `config.example.json`
- `examples/payload.preview.json`
- `scripts/invoke-wechat-sender.ps1`

禁止包含：

- Python 源码。
- `wechat-sender.exe`。
- Supabase 目录。
- `.env`。
- license key。
- Supabase token、admin token、service role key。
- 数据库连接串。
- `license_state.json`。
- `payload.*-contact-batches-*` smoke 生成目录。

## 发送前检查

只有用户明确要求发送时，Agent 才能把 payload 中的 `send` 改为 `true`。

发送前必须确认：

- 联系人或群名正确。
- 消息内容正确。
- 附件路径正确；单文件绝对路径没有被转换成父目录。
- 附件数量可接受。
- 授权状态有效。
- 用户明确允许真实发送。

如果只是验证流程，必须保持：

```json
{
  "send": false
}
```

## 导入后 smoke

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -LicenseStatus
```

预览 smoke 建议复制示例 payload 到临时目录后执行，避免在 skill 包目录生成批次文件：

```powershell
Copy-Item .\examples\payload.preview.json D:\tmp\wechat-payload.preview.json
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -PayloadJson D:\tmp\wechat-payload.preview.json
```

不要在导入 smoke 中运行 `send=true`。

