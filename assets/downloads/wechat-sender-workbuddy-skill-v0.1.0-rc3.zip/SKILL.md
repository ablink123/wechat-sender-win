---
name: wechat-sender-workbuddy
description: 调用已安装的 wechat-sender.exe，通过 Windows 桌面微信写入草稿、预览 payload，并在用户明确要求时发送消息。
---

# WeChat Sender Workbuddy Skill

## 作用

调用本机已安装并已激活的 `wechat-sender.exe`。

本 skill 包不包含 exe、Python 源码、Supabase 配置或任何密钥。它只负责让 Agent 生成 payload 并调用本机 exe。

## 使用前提

1. 用户已经安装 release 包中的 `wechat-sender.exe`。
2. 首次联网打开客户端会自动开启 7 天体验；付费用户可在 GUI 输入授权码激活。
3. 包内 `config.json` 已默认指向 `%LOCALAPPDATA%\WechatSender\wechat-sender.exe`；仅当客户端安装在其他位置时才需修改。
4. Windows 桌面微信已登录。

## 安全原则

- 默认只预览，不发送。
- 未获得用户明确发送确认时，payload 必须保持 `send=false`。
- 只有用户明确要求发送时，才允许 `send=true`。
- 真正发送前必须向用户确认联系人、消息、附件路径和授权状态。
- 用户选择单个文件时，`files_dir` 必须保留该文件的完整绝对路径，不得转换成父目录。
- 如果 exe 返回授权失败、联网失败或 license 失效，必须停止，不要尝试绕过。
- 退出码 `2` 或输出 `error_code=...` 时必须停止；不要拆分、重试或换调用方式绕过每日额度。
- 试用期每天最多发送给 20 个人或群：批量 5 人计 5 个，同一人重复发送会重复计入，正文和附件同次发送只计 1 个，预览不计额度。
- 不要保存或输出 license key、Supabase token、admin token、service role key。

## 推荐调用方式

优先使用 `--payload-json`：

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -PayloadJson D:\tmp\wechat-payload.json
```

预览 payload 示例：

```json
{
  "contacts": ["联系人或群名"],
  "message": "要写入的消息",
  "files_dir": null,
  "recursive": false,
  "max_files": 10,
  "send": false,
  "delay_seconds": 5,
  "batch_delay_seconds": 5,
  "operation_id": "由 Agent 为本次确认发送生成的 UUID；重试必须复用"
}
```

附件路径规则：

- `"files_dir": "D:\\资料\\报价单.pdf"`：只发送这一个文件。
- `"files_dir": "D:\\资料"`：发送该目录中的文件。
- 字段名 `files_dir` 为兼容名称，不代表必须传目录。
- Agent 不得为了“适配字段名”把单文件路径改成所在目录。


## Payload 文件位置

`wechat-sender.exe` 会在 payload 文件旁边生成批次联系人文件。Agent 应把运行时 payload 写到临时目录，例如 `D:\tmp` 或项目 scratch 目录，不要直接修改 skill 包内的示例 payload。
## 常用命令

查看授权状态：

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -LicenseStatus
```

检查微信窗口：

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -ListWindows -TitleFilter 微信
```

只聚焦微信：

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -FocusOnly
```

执行 payload 预览：

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -PayloadJson D:\tmp\wechat-payload.json
```

## 发送边界

当 payload 中 `send=true` 时，exe 会执行真实发送。Agent 必须在调用前确认：

- 用户明确要求发送。
- 联系人或群名正确。
- 消息内容正确。
- 附件路径正确；单文件没有被替换成父目录，目录文件数量可接受。
- 授权状态有效。

如果只是测试流程，必须使用 `send=false`。

试用额度耗尽时应向用户说明：额度将在北京时间明日 00:00 恢复，预览、名单检查和附件检查仍可使用；付费套餐不受试用期每日人数限制。


