# WeChat Sender Workbuddy Skill Package

本目录是 Agent 交付包草案，用于 Workbuddy / Codex 等 Agent 调用已安装的 `wechat-sender.exe`。

## 包内容

```text
wechat-sender-workbuddy/
├─ SKILL.md
├─ README.md
├─ config.json
├─ config.example.json
├─ examples/
│  └─ payload.preview.json
└─ scripts/
   └─ invoke-wechat-sender.ps1
```

## 不包含

- Python 源码
- Supabase 目录
- `.env`
- license key
- Supabase token
- admin token
- service role key
- 数据库连接串

## 安装步骤

1. 安装“微信本地通知助手客户端”，并确认 `wechat-sender.exe` 可运行。
2. 双击 exe 或运行 `--activate-code <license-key>` 完成授权。
3. 将本 ZIP 导入 WorkBuddy；包内 `config.json` 已指向默认安装路径，无需手工配置。
4. Agent 调用 `scripts/invoke-wechat-sender.ps1`。

`config.example.json` 仅用于客户端安装到非默认位置时参考，常规用户不需处理。

## 验证命令

```powershell
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -LicenseStatus
Copy-Item .\examples\payload.preview.json D:\tmp\wechat-payload.preview.json
.\scripts\invoke-wechat-sender.ps1 -ConfigPath .\config.json -PayloadJson D:\tmp\wechat-payload.preview.json
```

第二条命令默认 `send=false`，只预览，不操作微信发送。


